import streamlit as st

def app():
    st.title("Execução de Serviço")
    st.info("Executar os serviços selecionados e finalizar com observações")
